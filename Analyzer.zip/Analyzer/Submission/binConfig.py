import os
cpFiles=["Analyzer","Pileup"]
PathtoExecutable=os.getenv( 'ANALYSISDIR' )
outDir=os.path.join(os.getcwd(),"out")
